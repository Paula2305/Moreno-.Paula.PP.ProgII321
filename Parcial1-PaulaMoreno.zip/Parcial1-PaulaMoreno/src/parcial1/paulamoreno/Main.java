
package parcial1.paulamoreno;


public class Main {

    
    public static void main(String[] args) {
        Agencia agencianaves = new Agencia("Agencia super-espacial");
        
        Carguero carguero = new Carguero("Galactica", 20, 2000, 200);
        NaveDeExploracion naveexploracion = new NaveDeExploracion(TipoMision.CONTACTO,"Explora-2000", 20, 2000);
        CruceroEstelar crucero = new CruceroEstelar("Explora-2000", 20, 2000);
        
        
        try{
            agencianaves.agregarNave(carguero);
            agencianaves.agregarNave(naveexploracion);
            agencianaves.agregarNave(crucero);
        } catch (NaveRepetidaException ex){
            System.out.println(ex.getMessage());
        }
        
        agencianaves.mostrarNaves();
        agencianaves.iniciarExploracion();
    }
    
}
