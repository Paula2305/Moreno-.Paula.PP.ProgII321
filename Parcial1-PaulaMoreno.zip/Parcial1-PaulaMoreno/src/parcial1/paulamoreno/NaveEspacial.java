
package parcial1.paulamoreno;

import java.util.Objects;


public abstract class NaveEspacial {
    private String nombre;
    private int capacidadTripulacion;
    private int anioLanzamiento;

    public NaveEspacial(String nombre, int capacidadTripulacion, int anioLanzamiento) {
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.anioLanzamiento = anioLanzamiento;
    }
    
    // este metodo permite que se valide si el objeto no es nulo, si pertenece a esta intancia y que el atributo corresponda 
    @Override
    public boolean equals(Object o){
        if(this == o){
            return true;
        }
        if(o == null){
            return false;
        }
        if(o instanceof String str){
            return nombre.equals(str);
        }  
        if(o instanceof NaveEspacial other){
            return other.nombre.equals(nombre);
        }
        
        return false;
        
        
    }

    @Override
    public int hashCode(){
        return Objects.hash(nombre);
    }
    
    @Override
    public String toString() {
        return "NaveEspacial{" + "nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", anioLanzamiento=" + anioLanzamiento + '}';
    }
    
    public String getNombre(){
        return nombre;
    }
    
    
    
}
