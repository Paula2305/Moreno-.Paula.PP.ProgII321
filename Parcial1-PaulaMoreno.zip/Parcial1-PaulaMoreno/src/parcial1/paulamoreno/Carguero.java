
package parcial1.paulamoreno;


public class Carguero extends NaveEspacial implements Explorar {
    private static final int CAPACIDAD_CARGA_TONELADAS_MAX = 500 ;
    private static final int CAPACIDAD_CARGA_TONELADAS_MIN = 100 ;
    private int capacidadCarga;
    

    public Carguero(String nombre, int capacidadTripulacion, int anioLanzamiento,int capacidadCarga) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        validarToneladas(capacidadCarga);
        this.capacidadCarga = capacidadCarga;
    }
    
    private void validarToneladas(int numero){
        if(numero < CAPACIDAD_CARGA_TONELADAS_MIN || numero > CAPACIDAD_CARGA_TONELADAS_MAX){
            throw new IllegalArgumentException("No es un num valido");
        }
    }
    
    @Override
    public void explorar() {
        System.out.println("Iniciando exploracion de " + getNombre());
    }
    

    @Override
    public String toString() {
        return "Carguero{" + "capacidadCarga=" + capacidadCarga + '}';
    }
    
    
}

