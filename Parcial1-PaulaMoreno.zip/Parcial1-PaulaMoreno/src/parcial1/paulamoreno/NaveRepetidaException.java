
package parcial1.paulamoreno;

public class NaveRepetidaException extends RuntimeException {
    private static final String MESSAGE = "La nave ya existe";

    public NaveRepetidaException() {
        super(MESSAGE);
    }
    
}
