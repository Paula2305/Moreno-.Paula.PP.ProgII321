package parcial1.paulamoreno;


public enum TipoMision {
    CARTOGRAFIA, INVESTIGACION, CONTACTO
}
