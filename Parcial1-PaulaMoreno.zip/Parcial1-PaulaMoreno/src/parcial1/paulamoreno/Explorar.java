
package parcial1.paulamoreno;

public interface Explorar {
    
    void explorar();
}
