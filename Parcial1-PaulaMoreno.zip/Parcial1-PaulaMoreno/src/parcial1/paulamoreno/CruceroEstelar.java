package parcial1.paulamoreno;

public class CruceroEstelar extends NaveEspacial{

    public CruceroEstelar(String nombre, int capacidadTripulacion, int anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
    }

}
