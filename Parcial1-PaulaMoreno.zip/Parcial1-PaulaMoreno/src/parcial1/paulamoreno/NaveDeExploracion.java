
package parcial1.paulamoreno;

public class NaveDeExploracion extends NaveEspacial implements Explorar {
    private TipoMision mision;

    public NaveDeExploracion(TipoMision mision, String nombre, int capacidadTripulacion, int anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.mision = mision;
    }

    @Override
    public void explorar() {
        System.out.println("Iniciando exploracion de " + getNombre());
    }
    
    
    @Override
    public String toString() {
        return super.toString() + " NaveDeExploracion{" + "mision=" + mision + '}';
    }
    
    
}
